/**
 * Plugin Name: Scroll And Load For Elementor
 * Description: Adds infinite scroll and load more functionality to Elementor posts and products.
 * Tags:        pagination, paginate, scroll, infinite, infinity, load more, ajax, posts, products, elementor, woocommerce, jetsmartfilters
 * Plugin URI:  http://www.scrollandload.com/
 * Version:     1.0.0
 * Author:      Jifola
 * License:     GNU General Public License v2 or later
 * License URI: http://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: scroll-and-load-text-domain
 */
