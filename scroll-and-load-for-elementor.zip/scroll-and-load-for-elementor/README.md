# How to use

1. Locate "Scroll And Load" widget in the widget panel under "Scroll And Load" category, and place it anywhere on the page.

2. Apply Type: 
    * Select "Infinite Scroll" or "Load More".

3. Pagination for:
    * Elementor Pro Archive Posts: Set pagination for "Archive Posts" to "Previous/Next" or "Numbers + Previous/Next".
    * Elementor Pro Posts: Set pagination for "Posts" to "Previous/Next" or "Numbers + Previous/Next".
    * Elementor Pro Archive Products: If You are using "FacetWP" or "JetSmartFilters", default sorting can only be by most recent for "Scroll And Load" widget to work properly.
    * Elementor Pro Products: Enable pagination for "Products".
    * Use Custom Selectors: FacetWP and JetSmartFilters does NOT work with custom selectors.
	
4. Custom Selectors:
    * Use custom selectors.
   
5. FacetWP/jetSmartFilters:
    * Enable "FacetWP" or "JetSmartFilters" for compatibility. Only one can be active on a single page.
   
6. Bottom Offset:
    * If your site has a footer. This only applies to infinite scroll. The higher the number the sooner new items will load.
   
7. Animation time:
    * The items render animation time when new items are loaded.
   
8. Assign Load More ID:
    * Insert a section or inner section on the page and give it ID or class (E.g. load-more-container). And insert a Elementor button widget inside.
    * In the input for "Assign Load More ID" insert ID (E.g. #load-more-container) or class (E.g. .load-more-container).
    * Mandatory if you have applied type "Load More".
   
9. Assign Loading Image ID:
    * Insert a section or inner section on the page and give it ID or class (E.g. loading-image-container). And insert a image widget inside.
    * In the input for "Assign Loading Image ID" insert ID (E.g. #loading-image-container) or class (E.g. .loading-image-container).
	* Optional.
   
10. Assign No More Items ID:
    * Insert a section or inner section on the page and give it ID or class (E.g. no-more-items-container). And insert a heading or text widget inside.
    * In the input for "Assign No More Items ID" insert ID (E.g. #no-more-items-container) or class (E.g. .no-more-items-container).
	* Optional.

# Plugin structure

```
assets/
      /js
	  *scroll-and-load-facetwp.js
	  *scroll-and-load-jetsmartfilters.js
	  *scroll-and-load.js
	  
	  /css
	  *scroll-and-load.css
	     
includes/
        /widgets
        *index.php
		*scroll-and-load-widget.php
    
*scroll-and-load.php
*index.php
*plugin.php
*README.md
```

# Changelog

[1.0.0](xx/xx/xxxx)
* Release.

