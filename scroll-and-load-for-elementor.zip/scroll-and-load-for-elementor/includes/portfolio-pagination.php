<?php
/**
 * Portfolio pagination
 * 
 * Adds pagination to Elementor Pro Portfolio widget
 *
 * @since 1.0.0
 */
if ( ! is_admin() ){
						
    add_action( 'elementor/query/scroll-and-load', function( $query ) {
		
	    $posts_per_page = $query->get( 'posts_per_page' );
	
	    $post_type = $query->get( 'post_type' );
	
        $found_posts = wp_count_posts( $post_type )->publish;
	
	    if ( $found_posts % $posts_per_page == 0 ) {
		    $max_num_pages = $found_posts / $posts_per_page;
	    }
	    else {
		    $max_num_pages = $found_posts / $posts_per_page + 1;
	    }
		
        if ( get_query_var( 'page' ) > 1 ) { 
            $paged = get_query_var( 'page' ); 
        } 
	    elseif ( get_query_var( 'paged' ) > 1 ) { 
            $paged = get_query_var( 'paged' ); 
        } 
	    else { 
            $paged = 1; 
        }
		
	    $query->set( 'paged', $paged );
	
		if ( $paged <= $max_num_pages ) {
		?>
        <div class="portfolio-navigation">
        <?php
            echo paginate_links(
		        array(
	                'posts_per_page' => $posts_per_page,
                    'current'        => $paged,
                    'total'          => $max_num_pages
                )
	        );
		?>
        </div>
        <?php			
		}
				
    });	
	
}