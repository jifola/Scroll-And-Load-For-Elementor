<?php
namespace ScrollAndLoadNameSpace\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Scroll and load widget
 *
 * Elementor widget for Scroll And Load For Elementor.
 *
 * @since 1.0.0
 */
class Scroll_And_Load_Widget extends Widget_Base {
		
	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'scroll-and-load-widget';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Scroll And Load', 'scroll-and-load-text-domain' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-scroll';
	}
	
	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'scroll-and-load-category' ];
	}

	/**
	 * Retrieve the list of scripts the widget is depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'scroll-and-load-js' ];
	}

	/**
	 * Retrieve the list of styles the widget is depended on.
	 *
	 * Used to set styles dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget styles dependencies.
	 */
    public function get_style_depends() {
        return [ 'scroll-and-load-css' ];
    }

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function _register_controls() {
		
		/* Section controls start
           ========================================================================== */
		$this->start_controls_section(
			'section_settings',
			[
				'label' => __( 'Settings', 'scroll-and-load-text-domain' ),
			]
		);
		
		/* Documentation
           ========================================================================== */		
		$this->add_control(
	        'documentation',
			[
				'type'            => Controls_Manager::RAW_HTML,
				'raw'             => __( 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. <a href="https://elementor.com/" target="_blank">Documentation</a>', 'scroll-and-load-text-domain' ),
				'content_classes' => 'elementor-control-raw-html elementor-panel-alert elementor-panel-alert-info',
			]
		);
		
		/* Application
           ========================================================================== */
		$this->add_control(
			'application_heading',
			[
				'label' => __( 'Application', 'scroll-and-load-text-domain' ),
				'type'  => \Elementor\Controls_Manager::HEADING,			
			]
		);
		
		$this->add_control(
			'apply_type_setting',
			[
				'label'       => __( 'Apply Type', 'scroll-and-load-text-domain' ),
				'label_block' => true,
				'type'        => \Elementor\Controls_Manager::SELECT,
				'default'     => 'default',
				'options'     => [
					'default'         => __( 'Select...', 'scroll-and-load-text-domain' ),
					'infinite-scroll' => __( 'Infinite Scroll', 'scroll-and-load-text-domain' ),
					'load-more'       => __( 'Load More', 'scroll-and-load-text-domain' ),
				],
			]
		);
		
		$this->add_control(
			'pagination_for_setting',
			[
				'label'       => __( 'Pagination For', 'scroll-and-load-text-domain' ),
				'label_block' => true,
				'type'        => \Elementor\Controls_Manager::SELECT,
				'default'     => 'default',
				'options'     => [
					'default'                        => __( 'Select...', 'scroll-and-load-text-domain' ),
					'elementor-pro-archive-posts'    => __( 'Elementor Pro Archive Posts', 'scroll-and-load-text-domain' ),
					'elementor-pro-posts'            => __( 'Elementor Pro Posts', 'scroll-and-load-text-domain' ),
					'elementor-pro-archive-products' => __( 'Elementor Pro Archive Products', 'scroll-and-load-text-domain' ),
					'elementor-pro-products'         => __( 'Elementor Pro Products', 'scroll-and-load-text-domain' ),
					'use-custom-selectors'           => __( 'Use Custom Selectors', 'scroll-and-load-text-domain' ),
				],
			]
		);
		
		/* Custom selectors
           ========================================================================== */
		$this->add_control(
			'custom_selectors_heading',
			[
				'label'     => __( 'Custom Selectors', 'scroll-and-load-text-domain' ),
				'type'      => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',				
			]
		);
		
		$this->add_control(
			'custom_selector_navigation_setting',
			[
				'label'       => __( 'Navigation Selector', 'scroll-and-load-text-domain' ),
				'label_block' => true,
				'placeholder' => __( 'E.g. nav.navigation', 'scroll-and-load-text-domain' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
			]
		);
		
		$this->add_control(
			'custom_selector_next_setting',
			[
				'label'       => __( 'Next Selector', 'scroll-and-load-text-domain' ),
				'label_block' => true,
				'placeholder' => __( 'E.g. a.next', 'scroll-and-load-text-domain' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
			]
		);
		
		$this->add_control(
			'custom_selector_content_setting',
			[
				'label'       => __( 'Content Selector', 'scroll-and-load-text-domain' ),
				'label_block' => true,
				'placeholder' => __( 'E.g. div.items', 'scroll-and-load-text-domain' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
			]
		);
		
		$this->add_control(
			'custom_selector_item_setting',
			[
				'label'       => __( 'Item Selector', 'scroll-and-load-text-domain' ),
				'label_block' => true,
				'placeholder' => __( 'E.g. div.item', 'scroll-and-load-text-domain' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
			]
		);
		
		/* Bottom offset
           ========================================================================== */	
        $this->add_control(
			'bottom_offset_setting',
			[
				'label'     => __( '<strong>Bottom Offset</strong>', 'scroll-and-load-text-domain' ),
				'separator' => 'before',
				'type'      => \Elementor\Controls_Manager::NUMBER,
				'min'       => 0,
				'max'       => 100000,
				'step'      => 10,
				'default'   => 1000,
			]
		);
				
		/* Animation time
           ========================================================================== */
        $this->add_control(
			'animation_time_setting',
			[
				'label'     => __( '<strong>Animation Time</strong>', 'scroll-and-load-text-domain' ),
				'separator' => 'before',
				'type'      => \Elementor\Controls_Manager::NUMBER,
				'min'       => 0,
				'max'       => 100000,
				'step'      => 10,
				'default'   => 1000,
			]
		);
				
		/* Load more
           ========================================================================== */		
		$this->add_control(
			'load_more_setting',
			[
				'label'       => __( '<strong>Assign Load More ID</strong>', 'scroll-and-load-text-domain' ),
				'label_block' => true,
                'separator'   => 'before',
				'placeholder' => __( 'E.g. #load-more-container', 'scroll-and-load-text-domain' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
			]
		);
		
		/* Loading image
           ========================================================================== */		
		$this->add_control(
			'loading_image_setting',
			[
				'label'       => __( '<strong>Assign Loading Image ID</strong>', 'scroll-and-load-text-domain' ),
				'label_block' => true,
                'separator'   => 'before',
				'placeholder' => __( 'E.g. #loading-image-container', 'scroll-and-load-text-domain' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
			]
		);
		
		/* No more items
           ========================================================================== */		
		$this->add_control(
			'no_more_items_setting',
			[
				'label'       => __( '<strong>Assign No More Items ID</strong>', 'scroll-and-load-text-domain' ),
				'label_block' => true,
                'separator'   => 'before',
				'placeholder' => __( 'E.g. #no-more-items-container', 'scroll-and-load-text-domain' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
			]
		);
		
		/* Section controls end
           ========================================================================== */		
		$this->end_controls_section();		
	}

	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		
	    $settings = $this->get_settings_for_display();
		
        if ( ! is_admin() ) { // Only frontend
			
		    // It is faster to hide elements here than in the script so let's do that as the first thing    
		    ?>
            <style>
			    <?php echo $settings['loading_image_setting']; ?> {display: none;} /* Do not use !important */
		        <?php echo $settings['no_more_items_setting']; ?> {display: none;} /* Do not use !important */
				<?php echo $settings['load_more_setting']; ?> {display: none;} /* Do not use !important */
				.elementor-widget-scroll-and-load-widget {display:none !important;}	
            </style>
            <?php
        }
					
		/**
		 * apply_type_setting
		 * 
		 * Apply conditions and return parameters.
		 * 
		 * Infinite scroll is default.
		 */		
		if( $settings['apply_type_setting'] == 'load-more' ) {
			
		    $options['event'] = 'click';		
		}
		
		/**
		 * pagination_for_setting
		 * 
		 * Apply conditions and return parameters.
		 * 
		 * Custom selectors are default.
		 */
		
		// Elementor Pro Archive Posts and Elementor Pro Posts
		if( $settings['pagination_for_setting'] == 'elementor-pro-archive-posts' || $settings['pagination_for_setting'] == 'elementor-pro-posts' ) {
			
            if ( ! is_admin() ) { // Only frontend		   
		    ?>
            <style>
				nav.elementor-pagination {display:none !important;}
            </style>
            <?php
            }
			
		    $options['navigationSelector'] = 'nav.elementor-pagination';
		    $options['nextSelector']       = 'a.page-numbers.next';
		    $options['contentSelector']    = 'div.elementor-element';
		    $options['itemSelector']       = 'article.elementor-post';
		}
		// Elementor Pro Archive Products and Elementor Pro Products
		elseif( $settings['pagination_for_setting'] == 'elementor-pro-archive-products' || $settings['pagination_for_setting'] == 'elementor-pro-products' ) {
			
            if ( ! is_admin() ) { // Only frontend		   
		    ?>
            <style>
				nav.woocommerce-pagination {display:none !important;}
            </style>
            <?php
            }
			
		    $options['contentSelector']    = 'ul.products';
		    $options['itemSelector']       = 'li.product';
			$options['navigationSelector'] = 'nav.woocommerce-pagination';
		    $options['nextSelector']       = 'a.next.page-numbers';
		}
		// Custom selectors
		else {
			
		    ?>
            <style>
			    <?php echo $settings['custom_selector_navigation_setting']; ?> {display: none !important;}
            </style>
            <?php
			
		    $options['navigationSelector'] = $settings['custom_selector_navigation_setting'];
		    $options['nextSelector']       = $settings['custom_selector_next_setting'];
		    $options['contentSelector']    = $settings['custom_selector_content_setting'];
		    $options['itemSelector']       = $settings['custom_selector_item_setting'];				
		}
		
		// Load more button
		$options['loadMore']      = $settings['load_more_setting'];
		
		// Loading image
		$options['loadingImage']  = $settings['loading_image_setting'];
		
		// No more items message
		$options['finishText']    = $settings['no_more_items_setting'];
		
		// Animation time
		$options['animationTime'] = $settings['animation_time_setting'];
		
		// Bottom offset
		$options['bottomOffset']  = $settings['bottom_offset_setting'];
			
        // Pass parameters to scroll-and-load-js
		wp_localize_script( 'scroll-and-load-js', 'selector', $options );
	    wp_enqueue_script( 'scroll-and-load-js' );
	}
		
}
