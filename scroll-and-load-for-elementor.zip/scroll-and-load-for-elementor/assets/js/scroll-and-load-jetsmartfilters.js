/**
 * Scroll and load jetsmartfilters js
 *
 * @since 1.0.0
 */
(function($) {
	'use strict';
	jQuery(document).ready(function($) {
		$(window).load(function() {
			
			var nextSelector       = selector['nextSelector'];
			var navigationSelector = selector['navigationSelector'];
			var contentSelector    = selector['contentSelector'];
			var itemSelector       = selector['contentSelector'] + ' ' + selector['itemSelector'];
			
			var loadMore           = selector['loadMore'];
			var finishText         = selector['finishText'];
			var loadingImage       = selector['loadingImage'];
			
			var animationTime      = parseInt(selector['animationTime']);
			var bottomOffset       = parseInt(selector['bottomOffset']);
			
			var destUrlInit        = $(nextSelector).attr('href'); // Save for Jetsmartfilters reset
			var paginationType     = selector['paginationType']; // Jetsmartfilters has 2 variations of pagination paths
			var url                = window.location.href; // Used for Jetsmartfilters pagination path
			
			var trigger            = selector['event'];
			var destUrl            = $(nextSelector).attr('href');
			var finished           = false;
			var flag               = true; // Disable scroll load
			var imageRatio         = false;
			
			var nextInit = $(navigationSelector).find(nextSelector); // Check if navigation exists on page load
			
			if (nextInit.length !== 0) {
				flag = false; // Enable scroll load	
				$(loadMore).show();
			}
			else {
				$(finishText).show();
			}
			    					
			if ('click' == trigger) {
				load_on_click();
			} 
			else {
				load_on_scroll();
			}
			
			// Check for post thumbnail image ratio on page load
			setTimeout(function() {
			    if ($('.elementor-post .elementor-post__thumbnail').first().is('.elementor-post__thumbnail.elementor-fit-height')) {	
				    imageRatio = true;
			    }	
			}, 1000);
			
			// Check for post thumbnail image ratio on window resize
            $(window).resize(function() {
                if($('.elementor-post .elementor-post__thumbnail').first().is('.elementor-post__thumbnail.elementor-fit-height')) {
				    $('.elementor-post__thumbnail').addClass('elementor-fit-height');
					imageRatio = true;
			    }
				else {
				    $('.elementor-post__thumbnail').removeClass('elementor-fit-height');
					imageRatio = false;
				}
            });

			function salfe_load_more() {
				$.ajax({		
					url: destUrl,
					beforeSend: function() {
						
						$(loadingImage).show(); // Show loading image
						flag = true; // Disable scroll load for now				
					},
					success: function(results) {
						
						$(loadingImage).hide(); // Hide loading image
									
						setTimeout(function() {
						    flag = false; // Enable scroll load again
						}, 500);

						var obj  = $(results);
						var elem = obj.find(itemSelector);
						var next = obj.find(nextSelector);				

						if (next.length !== 0) {			
						    $(nextSelector).attr('href', next.attr('href'));					
						}

						elem.each(function() {					
							$(itemSelector)
								.last()
								.after($(this).css({opacity:0}).animate({opacity:1}, animationTime));
							if (imageRatio === true) {
							    $('.elementor-post__thumbnail').addClass('elementor-fit-height');
							}
						});
										
						if (next.length !== 0) {					
                            destUrl = $(nextSelector).attr('href');
						}
						else {				
							finished = true; // Disable scroll load
							$(loadMore).hide();
							$(finishText).show();
						}
					},
					error: function(results) {

					}		
				});
			}

			function load_on_scroll() {
				$(window).on('scroll', function() {	
					
					var t    = $(this),
					    elem = $(document);

					if (typeof elem == 'undefined') {
						return;
					}

					if (
						flag === false &&
						!finished && 
						t.scrollTop() + bottomOffset >= 
						    elem.height() - t.height()
					) {
						salfe_load_more();
					}
					
				});
			}

			function load_on_click() {
				$('body').on('click', loadMore + ' a', function(e) {	
					e.preventDefault(); // If button "Link" input is not empty
					salfe_load_more();
				});
			}
			
            $(document).on('jet-filter-loaded', function($scope, JetSmartFilters, provider, query, queryID) {
				
				var next = $(navigationSelector).find(nextSelector);
				
				if (next.length !== 0) {
					
				    var filter = $.param(queryID);
								
				    if ('' === filter) {  // If no filters are selected or have been reset
					    destUrl = destUrlInit;
				    }
				    else if ('product-page' === paginationType) {	// Elementor Pro Products
						destUrl = url + '?jet-smart-filters=' + query + '/default&' + filter + '&product-page=2';
				    }
				    else { // Elementor Pro Archive, Elementor Pro Posts and Elementor Pro Archive Products
						destUrl = url + 'page/2/' + '?jet-smart-filters=' + query + '/default&' + filter;
				    }
				
					flag = false; // Enable scroll load
					$(loadMore).show();
					$(finishText).hide();				
				}
				else {
					flag = true; // Disable scroll load
					$(loadMore).hide();
				}
							
            });	
					
		});
	});	
})(jQuery);
