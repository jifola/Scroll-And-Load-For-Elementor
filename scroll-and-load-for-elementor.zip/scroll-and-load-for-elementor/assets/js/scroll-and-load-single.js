/**
 * Scroll and load js
 *
 * @since 1.0.0
 */
(function($) {
	'use strict';
	jQuery(document).ready(function($) {
		$(window).load(function() {
			
			var nextSelector       = selector['nextSelector'];
			var navigationSelector = selector['navigationSelector'];
			var itemSelector       = selector['itemSelector'];
			
			var widgetSelector     = selector['widgetSelector'];
			var loadMore           = selector['loadMore'];
			var finishText         = selector['finishText'];
			var loadingImage       = selector['loadingImage'];
			
			var imageRatio         = selector['imageRatio'];
			var animationTime      = parseInt(selector['animationTime']);
			var bottomOffset       = parseInt(selector['bottomOffset']);
						
			var trigger            = selector['event'];
			var destUrl            = $(nextSelector).attr('href');
			var finished           = false;
			var flag               = false;
													
			$(loadMore).show();

			$(loadMore + ' a').css('cursor', 'pointer'); // If button "Link" input is empty
			    					
			if ('click' == trigger) {
				load_on_click();
			} 
			else {
				load_on_scroll();
			}
			
			// Makes it easier to manage when inserting new posts and moving plugin parts
			$('<div id="salfe-separator"></div>').insertAfter(itemSelector);
			
			var salfeSeparator = '#salfe-separator';
       
			$(loadMore).insertAfter(salfeSeparator);
			$(finishText).insertAfter(salfeSeparator);
			$(loadingImage).insertAfter(salfeSeparator);
					
			function salfe_load_more() {
				$.ajax({
					url: destUrl,
					beforeSend: function() {
						
						$(loadingImage).show(); // Show loading image
						flag = true; // Disable scroll load for now
					},
					success: function(results) {
						
					    $(loadingImage).hide(); // Hide loading image
		
						setTimeout(function() {
						    flag = false; // Enable scroll load again
						}, 500);

						var obj  = $(results);
						var next = obj.find(nextSelector);
						var id   = obj.find("#salfe-id").val();
						
						if (next.length !== 0) {			
						    $(nextSelector).attr('href', next.attr('href'));					
						}
						
						// Remove all parts of the plugin from next post or there will be all kinds of trouble
                        obj.find(widgetSelector).remove();
						obj.find(loadMore).remove();
                        obj.find(loadingImage).remove();
						obj.find(finishText).remove();
						
						// Add next post CSS to head
						obj.filter('#elementor-post-' + id + '-css').appendTo('head');
						
						// Insert next post
						obj.filter(itemSelector).css({opacity:0}).insertBefore(salfeSeparator).animate({opacity:1}, animationTime);
												
						// Change url
						history.pushState({}, '', destUrl); // Changing the title here is not supported by all browsers
						
						// Change title
						var newTitle = obj.filter('title').text();
						document.title = newTitle;
						  
						if (next.length !== 0) {					
                            destUrl = $(nextSelector).attr('href');
						}
						else {				
							finished = true; // Disable scroll load
							$(loadMore).hide();
							$(finishText).show();
						}
						
					},
					error: function(results) {

					}		
				});
			}

			function load_on_scroll() {
				$(window).on('scroll', function() {	
					
					var t    = $(this),
					    elem = $(document);

					if (typeof elem == 'undefined') {
						return;
					}

					if (
						flag === false &&
						!finished && 
						t.scrollTop() + bottomOffset >= 
						    elem.height() - t.height()
					) {
						salfe_load_more();
					}
					
				});
			}

			function load_on_click() {
				$('body').on('click', loadMore + ' a', function(e) {	
					e.preventDefault(); // If button "Link" input is not empty
					salfe_load_more();			
				});
			}
					
		});
	});	
})(jQuery);
