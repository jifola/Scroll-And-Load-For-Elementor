/**
 * Scroll and load js
 *
 * @since 1.0.0
 */
(function($) {
	'use strict';
	jQuery(document).ready(function($) {
		$(window).load(function() {
			
			var nextSelector       = selector['nextSelector'];
			var navigationSelector = selector['navigationSelector'];
			var contentSelector    = selector['contentSelector'];
			var itemSelector       = selector['contentSelector'] + ' ' + selector['itemSelector'];
			
			var loadMore           = selector['loadMore'];
			var finishText         = selector['finishText'];
			var loadingImage       = selector['loadingImage'];
			
			var animationTime      = parseInt(selector['animationTime']);
			var bottomOffset       = parseInt(selector['bottomOffset']);
			
			var widgetClass        = selector['widgetClass'];
			var widgetType         = selector['widgetType'];
			
			var trigger            = selector['event'];
			var destUrl            = $(nextSelector).attr('href');
			var finished           = false;
			var flag               = true; // Disable scroll load
				
			var nextInit = $(navigationSelector).find(nextSelector); // Check if navigation exists on page load
			
			if (nextInit.length !== 0) {
				flag = false; // Enable scroll load	
				$(loadMore).show();
			}
			else {
				$(finishText).show();
			}
			    					
			if ('click' == trigger) {
				load_on_click();
			} 
			else {
				load_on_scroll();
			}
			
			if (widgetType == 'archive-posts') { // Check which skin is being used for Elementor Pro Archive Posts
                $(".elementor-posts-container").ready(function() {			
			        if ($('.elementor-posts-container').is('.elementor-posts--skin-classic')) {				
						widgetType = 'archive-posts.archive_classic';		
			        }
			        else if ($('.elementor-posts-container').is('.elementor-posts--skin-cards')) {
						widgetType = 'archive-posts.archive_cards';
			        }
			        else if ($('.elementor-posts-container').is('.elementor-posts--skin-full_content')) {
						widgetType = 'archive-posts.archive_full_content';
			        } 
                });
			}
			
			if (widgetType == 'posts') { // Check which skin is being used for Elementor Pro Posts	
                $(".elementor-posts-container").ready(function() {
			        if ($('.elementor-posts-container').is('.elementor-posts--skin-classic')) {	
						widgetType = 'posts.classic';		
			        }
			        else if ($('.elementor-posts-container').is('.elementor-posts--skin-cards')) {
						widgetType = 'posts.cards';
			        }
			        else if ($('.elementor-posts-container').is('.elementor-posts--skin-full_content')) {
						widgetType = 'posts.full_content';
			        } 
                });
			}
						
			function salfe_load_more() {
				$.ajax({		
					url: destUrl,
					beforeSend: function() {
						
						$(loadingImage).show(); // Show loading image
						flag = true; // Disable scroll load for now				
					},
					success: function(results) {
						
						$(loadingImage).hide(); // Hide loading image
									
						setTimeout(function() {
						    flag = false; // Enable scroll load again
						}, 500);

						var obj  = $(results);
						var elem = obj.find(itemSelector);
						var next = obj.find(nextSelector);				

						if (next.length !== 0) {			
						    $(nextSelector).attr('href', next.attr('href'));					
						}

						elem.each(function() {					
							$(itemSelector)
								.last()
								.after($(this).css({opacity:0}).animate({opacity:1}, animationTime));
							elementorFrontend.hooks.doAction('frontend/element_ready/' + widgetType, jQuery(widgetClass)); // Apply styles and functions to newly loaded items
						});
										
						if (next.length !== 0) {					
                            destUrl = $(nextSelector).attr('href');
						}
						else {				
							finished = true; // Disable scroll load
							$(loadMore).hide();
							$(finishText).show();
						}
					},
					error: function(results) {

					}		
				});
			}

			function load_on_scroll() {
				$(window).on('scroll', function() {	
					
					var t    = $(this),
					    elem = $(document);

					if (typeof elem == 'undefined') {
						return;
					}

					if (
						flag === false &&
						!finished && 
						t.scrollTop() + bottomOffset >= 
						    elem.height() - t.height()
					) {
						salfe_load_more();
					}
					
				});
			}

			function load_on_click() {
				$('body').on('click', loadMore + ' a', function(e) {	
					e.preventDefault(); // If button "Link" input is not empty
					salfe_load_more();
				});
			}
					
		});
	});	
})(jQuery);
